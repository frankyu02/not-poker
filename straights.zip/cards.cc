#include "cards.h"
#include <string>
using namespace std;

Card::Card(Suit s, Rank r){
	suit = s;
	rank = r;
}

Suit Card::getSuit() const{
	return suit;
}
Rank Card::getRank() const{
	return rank;
}

bool operator== (const Card & c1, const Card & c2){
	return c1.getSuit() == c2.getSuit() && c1.getRank() == c2.getRank();
}
ostream &operator<<(ostream &out, const Card & c){
	string suites[4] = {"C", "D", "H", "S"};
	string ranks[13] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"};
	out << ranks[c.getRank()] << suites[c.getSuit()];
	return out;
}
istream &operator>>(istream &in, Card &c){
	string suites = "CDHS";
	string ranks = "A23456789TJQK";
	char r, s;
	in >> r >> s;
	c.rank = (Rank)ranks.find(r);
	c.suit = (Suit)suites.find(s);
	return in;
}
